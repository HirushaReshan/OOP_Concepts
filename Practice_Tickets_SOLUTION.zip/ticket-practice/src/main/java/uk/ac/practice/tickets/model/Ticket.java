package uk.ac.practice.tickets.model;

// PROVIDED: read it, do not edit it.
public abstract class Ticket {

    private Long id;
    private String eventName;
    private double basePrice;

    public Ticket() {}

    public Ticket(Long id, String eventName, double basePrice) {
        this.id = id;
        this.eventName = eventName;
        this.basePrice = basePrice;
    }

    public Long getId() { return id; }
    public String getEventName() { return eventName; }
    public double getBasePrice() { return basePrice; }

    public void setId(Long id) { this.id = id; }
    public void setEventName(String eventName) { this.eventName = eventName; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }

    // Every ticket type must say how much it costs...
    public abstract double calculatePrice();

    // ...and describe itself in one line.
    public abstract String getSummary();
}
