package uk.ac.practice.tickets.service;

import org.springframework.stereotype.Service;
import uk.ac.practice.tickets.model.Ticket;
import uk.ac.practice.tickets.repository.TicketRepository;

import java.util.List;

@Service
public class TicketService {

    private final TicketRepository repository;

    // PROVIDED: constructor injection. Read it, do not change it.
    public TicketService(TicketRepository repository) {
        this.repository = repository;
    }

    // PROVIDED
    public List<Ticket> getAllTickets() {
        return repository.findAll();
    }

    // TASK 3 [20 marks with the handler]:
    //   create TicketNotFoundException (message must include the id),
    //   then make this method throw it when the id does not exist.
    public Ticket getTicketById(Long id) {
        return null; // TODO
    }

    // TASK 4: add  public Ticket createVipTicket(VipTicket ticket)  that saves the ticket
    //         through the repository and returns it.
    // TASK 5: before saving, reject a blank event name or a base price <= 0 by throwing
    //         a new InvalidTicketException. Nothing invalid may be saved.
}
