package uk.ac.practice.tickets.model;

// TASK 1 (solution)
public class StandardTicket extends Ticket {

    private String seatRow;

    public StandardTicket() {}

    public StandardTicket(Long id, String eventName, double basePrice, String seatRow) {
        super(id, eventName, basePrice);
        this.seatRow = seatRow;
    }

    public String getSeatRow() { return seatRow; }
    public void setSeatRow(String seatRow) { this.seatRow = seatRow; }

    @Override
    public double calculatePrice() {
        return getBasePrice();
    }

    @Override
    public String getSummary() {
        return "Standard: " + getEventName() + " | Row " + seatRow + " | £" + calculatePrice();
    }
}
