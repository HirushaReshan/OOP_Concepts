package uk.ac.practice.tickets.model;

// TASK 2 (solution): this whole file is new.
public class VipTicket extends Ticket {

    public static final double VIP_MULTIPLIER = 1.5;
    public static final double BACKSTAGE_FEE = 50.0;

    private boolean backstagePass;

    public VipTicket() {}

    public VipTicket(Long id, String eventName, double basePrice, boolean backstagePass) {
        super(id, eventName, basePrice);
        this.backstagePass = backstagePass;
    }

    public boolean isBackstagePass() { return backstagePass; }
    public void setBackstagePass(boolean backstagePass) { this.backstagePass = backstagePass; }

    @Override
    public double calculatePrice() {
        double price = getBasePrice() * VIP_MULTIPLIER;
        if (backstagePass) {
            price += BACKSTAGE_FEE;
        }
        return price;
    }

    @Override
    public String getSummary() {
        String backstage = "no";
        if (backstagePass) {
            backstage = "yes";
        }
        return "VIP: " + getEventName() + " | Backstage: " + backstage + " | £" + calculatePrice();
    }
}
