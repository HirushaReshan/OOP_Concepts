package edu.practice.scheduler.service;

import edu.practice.scheduler.dto.CommitRequest;
import edu.practice.scheduler.dto.PlanRequest;
import edu.practice.scheduler.dto.Rejection;
import edu.practice.scheduler.dto.Reservation;
import edu.practice.scheduler.dto.SchedulePlan;
import edu.practice.scheduler.error.CommitConflictException;
import edu.practice.scheduler.error.WorkloadNotFoundException;
import edu.practice.scheduler.model.Workload;
import edu.practice.scheduler.repo.WorkloadRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class SchedulerService {

    private final WorkloadRepository repo;

    // Confirmed (committed) reservations: the only persistent scheduling state.
    private final List<Reservation> confirmed = new ArrayList<>();

    // runKey -> the request and the plan it produced, for idempotent retries.
    private final Map<String, CommitRequest> commitRequests = new HashMap<>();
    private final Map<String, SchedulePlan> commitPlans = new HashMap<>();

    public SchedulerService(WorkloadRepository repo) {
        this.repo = repo;
    }

    public Collection<Workload> all() {
        return repo.all();
    }

    // TASK 2
    public int urgency(long id, int nowTick) {
        Workload workload = repo.find(id);
        if (workload == null) {
            throw new WorkloadNotFoundException(id);
        }
        return workload.urgencyAt(nowTick);
    }

    // TASK 2: urgency DESC, then id ASC (polymorphic urgencyAt)
    public List<Workload> ranked(int nowTick) {
        if (nowTick < 0) {
            throw new IllegalArgumentException("nowTick cannot be negative");
        }
        return repo.all().stream()
                .sorted(Comparator.comparingInt((Workload w) -> w.urgencyAt(nowTick)).reversed()
                        .thenComparingLong(Workload::getId))
                .toList();
    }

    // TASK 4
    public synchronized List<Reservation> reservations() {
        return confirmed.stream()
                .sorted(Comparator.comparingInt(Reservation::startTick)
                        .thenComparingLong(Reservation::id))
                .toList();
    }

    // TASK 3: dry run, never changes 'confirmed'
    public synchronized SchedulePlan preview(PlanRequest request) {
        validate(request);
        int now = request.nowTick();
        int windowEnd = now + request.horizon();           // exclusive end of the window

        Set<Long> alreadyBooked = new HashSet<>();
        for (Reservation r : confirmed) {
            alreadyBooked.add(r.id());
        }

        List<Reservation> occupied = new ArrayList<>(confirmed);   // copy: confirmed + this preview
        List<Reservation> selected = new ArrayList<>();
        List<Rejection> rejected = new ArrayList<>();

        for (Workload w : ranked(now)) {
            if (alreadyBooked.contains(w.getId())) {
                continue;                                  // committed earlier: never book twice
            }
            if (w.getCpuCores() > request.cpuCapacity() || w.getMemoryMb() > request.memoryCapacity()) {
                rejected.add(new Rejection(w.getId(), "EXCEEDS_CAPACITY"));
                continue;
            }
            int earliest = Math.max(now, w.getReleaseTick());
            int windowLatest = windowEnd - w.getDurationTicks();
            if (earliest > windowLatest) {
                String reason = "NO_SLOT";
                if (w.getReleaseTick() > now) {
                    reason = "RELEASE_OUTSIDE_WINDOW";
                }
                rejected.add(new Rejection(w.getId(), reason));
                continue;
            }
            if (w.latestStartTick() < earliest) {
                rejected.add(new Rejection(w.getId(), "DEADLINE"));
                continue;
            }
            int latest = Math.min(windowLatest, w.latestStartTick());

            Integer start = null;
            for (int s = earliest; s <= latest; s++) {
                if (fits(occupied, s, s + w.getDurationTicks(), w, request)) {
                    start = s;
                    break;
                }
            }
            if (start == null) {
                rejected.add(new Rejection(w.getId(), "NO_SLOT"));
            } else {
                Reservation r = new Reservation(w.getId(), start, start + w.getDurationTicks(),
                        w.getCpuCores(), w.getMemoryMb());
                selected.add(r);
                occupied.add(r);
            }
        }
        return new SchedulePlan(now, request.horizon(), List.copyOf(selected), List.copyOf(rejected));
    }

    // TASK 4: idempotent commit
    public synchronized SchedulePlan commit(CommitRequest request) {
        if (request == null || request.runKey() == null || request.runKey().isBlank()) {
            throw new IllegalArgumentException("runKey is required");
        }
        String key = request.runKey();
        if (commitRequests.containsKey(key)) {
            if (commitRequests.get(key).equals(request)) {
                return commitPlans.get(key);               // identical retry: same plan, no new bookings
            }
            throw new CommitConflictException(key);        // same key, different values: 409
        }
        SchedulePlan plan = preview(request.asPlanRequest());
        confirmed.addAll(plan.selected());                 // all-or-nothing inside synchronized
        commitRequests.put(key, request);
        commitPlans.put(key, plan);
        return plan;
    }

    // Half-open interval [start, end): every tick must fit both CPU and memory.
    private boolean fits(List<Reservation> occupied, int start, int end, Workload w, PlanRequest req) {
        for (int tick = start; tick < end; tick++) {
            int cpu = w.getCpuCores();
            int mem = w.getMemoryMb();
            for (Reservation r : occupied) {
                if (r.startTick() <= tick && tick < r.endTickExclusive()) {
                    cpu += r.cpuCores();
                    mem += r.memoryMb();
                }
            }
            if (cpu > req.cpuCapacity() || mem > req.memoryCapacity()) {
                return false;
            }
        }
        return true;
    }

    private void validate(PlanRequest r) {
        if (r == null) {
            throw new IllegalArgumentException("Request body is required");
        }
        if (r.nowTick() < 0 || r.nowTick() > 1_000_000) {
            throw new IllegalArgumentException("nowTick must be between 0 and 1,000,000");
        }
        if (r.horizon() < 1 || r.horizon() > 24) {
            throw new IllegalArgumentException("horizon must be between 1 and 24");
        }
        if (r.cpuCapacity() < 1 || r.cpuCapacity() > 64) {
            throw new IllegalArgumentException("cpuCapacity must be between 1 and 64");
        }
        if (r.memoryCapacity() < 1 || r.memoryCapacity() > 1_000_000) {
            throw new IllegalArgumentException("memoryCapacity must be between 1 and 1,000,000");
        }
    }
}
