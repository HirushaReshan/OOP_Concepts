package edu.practice.scheduler.controller;

import edu.practice.scheduler.dto.CommitRequest;
import edu.practice.scheduler.dto.PlanRequest;
import edu.practice.scheduler.dto.Reservation;
import edu.practice.scheduler.dto.SchedulePlan;
import edu.practice.scheduler.model.Workload;
import edu.practice.scheduler.service.SchedulerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/workloads")
public class SchedulerController {

    private final SchedulerService service;

    public SchedulerController(SchedulerService service) {
        this.service = service;
    }

    @GetMapping
    public Collection<Workload> all() {
        return service.all();
    }

    @GetMapping("/{id}/urgency")
    public Map<String, Object> urgency(@PathVariable long id, @RequestParam int nowTick) {
        return Map.of("id", id, "nowTick", nowTick, "urgency", service.urgency(id, nowTick));
    }

    @GetMapping("/ranked")
    public List<Workload> ranked(@RequestParam int nowTick) {
        return service.ranked(nowTick);
    }

    @PostMapping("/preview")
    public SchedulePlan preview(@RequestBody PlanRequest request) {
        return service.preview(request);
    }

    @PostMapping("/commit")
    public SchedulePlan commit(@RequestBody CommitRequest request) {
        return service.commit(request);
    }

    @GetMapping("/reservations")
    public List<Reservation> reservations() {
        return service.reservations();
    }
}
