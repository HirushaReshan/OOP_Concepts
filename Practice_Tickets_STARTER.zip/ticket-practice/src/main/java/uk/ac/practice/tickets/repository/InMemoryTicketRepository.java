package uk.ac.practice.tickets.repository;

import org.springframework.stereotype.Repository;
import uk.ac.practice.tickets.model.StandardTicket;
import uk.ac.practice.tickets.model.Ticket;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// PROVIDED: read it, do not edit it (except the two seed lines marked for Tasks 1 and 2).
@Repository
public class InMemoryTicketRepository implements TicketRepository {

    private final List<Ticket> tickets = new ArrayList<>();
    private Long nextId = 1L;

    public InMemoryTicketRepository() {
        // TASK 1: once your StandardTicket constructor exists, uncomment the next line.
        // save(new StandardTicket(null, "Rock Night", 40.0, "F"));
        // TASK 2: once VipTicket exists, uncomment the next line (and add its import).
        // save(new VipTicket(null, "Jazz Evening", 60.0, true));
    }

    @Override
    public List<Ticket> findAll() {
        return tickets;
    }

    @Override
    public Optional<Ticket> findById(Long id) {
        return tickets.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst();
    }

    @Override
    public Ticket save(Ticket ticket) {
        if (ticket.getId() == null) {
            ticket.setId(nextId++);
        }
        tickets.add(ticket);
        return ticket;
    }

    @Override
    public void deleteById(Long id) {
        tickets.removeIf(t -> t.getId().equals(id));
    }
}
