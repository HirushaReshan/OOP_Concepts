package uk.ac.practice.tickets.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

// TASK 3: add a handler method that turns TicketNotFoundException into 404
//         with an ErrorResponse body.
// TASK 5: add a second handler method that turns InvalidTicketException into 400.
@ControllerAdvice
public class GlobalExceptionHandler {

    // TODO

}
