package uk.ac.practice.tickets.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import uk.ac.practice.tickets.model.Ticket;
import uk.ac.practice.tickets.model.VipTicket;
import uk.ac.practice.tickets.service.TicketService;

import java.util.List;

@RestController
@RequestMapping("/tickets")
public class TicketController {

    private final TicketService service;

    // PROVIDED: constructor injection. Read it, do not change it.
    public TicketController(TicketService service) {
        this.service = service;
    }

    // PROVIDED
    @GetMapping
    public List<Ticket> getAll() {
        return service.getAllTickets();
    }

    // TASK 4 (solution)
    @GetMapping("/{id}")
    public Ticket getById(@PathVariable Long id) {
        return service.getTicketById(id);
    }

    // TASK 4 (solution)
    @PostMapping("/vip")
    @ResponseStatus(HttpStatus.CREATED)
    public Ticket createVip(@RequestBody VipTicket ticket) {
        return service.createVipTicket(ticket);
    }

    // STRETCH (solution)
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.deleteTicket(id);
    }
}
