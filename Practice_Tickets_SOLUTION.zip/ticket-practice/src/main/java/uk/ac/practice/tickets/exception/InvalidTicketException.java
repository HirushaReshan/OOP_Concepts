package uk.ac.practice.tickets.exception;

// TASK 5 (solution): new file.
public class InvalidTicketException extends RuntimeException {

    public InvalidTicketException(String message) {
        super(message);
    }
}
