package uk.ac.practice.tickets.exception;

// TASK 3 (solution): new file.
public class TicketNotFoundException extends RuntimeException {

    public TicketNotFoundException(Long id) {
        super("Ticket not found with id: " + id);
    }
}
