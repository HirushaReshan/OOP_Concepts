# Practice Paper: Concert Tickets (100 minutes)

This is a PRACTICE paper in the shape of the Lecture 6 mock. It is not the real exam
and does not predict its topic.

## Task 0: load
Unzip, open the folder containing pom.xml in IntelliJ, wait for Maven, run
TicketApplication, then open http://localhost:8080/tickets in a browser.
You should see an empty list: []

## Provided: read, do not edit
- model/Ticket.java (abstract parent)
- repository/TicketRepository.java and InMemoryTicketRepository.java
  (only the two seed lines marked for Tasks 1 and 2 may be uncommented)
- exception/ErrorResponse.java
- the constructors of TicketService and TicketController (constructor injection)

## Task 1 [18]: complete StandardTicket
Field seatRow; full constructor calling super(...); calculatePrice() returns the base price;
getSummary() returns "Standard: <eventName> | Row <seatRow> | £<price>".
Then uncomment the standard seed line in InMemoryTicketRepository.

## Task 2 [22]: create VipTicket (new file, model package)
Extends Ticket. Field: boolean backstagePass. Two constructors (no-arg, and full:
id, eventName, basePrice, backstagePass). Getter isBackstagePass() and a setter.
calculatePrice() = basePrice x 1.5, plus 50.0 if it has a backstage pass.
getSummary() returns "VIP: <eventName> | Backstage: yes|no | £<price>".
Then uncomment the VIP seed line in InMemoryTicketRepository.

## Task 3 [20]: not found -> 404
Create TicketNotFoundException (unchecked; message "Ticket not found with id: <id>").
Make TicketService.getTicketById throw it. In GlobalExceptionHandler, return 404 with an
ErrorResponse built from the exception's message.
UPLOAD A SAFETY COPY NOW.

## Task 4 [20]: endpoints
GET /tickets/{id} returns 200 with the ticket.
POST /tickets/vip takes a VipTicket JSON body, saves it through the service, returns 201
with the saved ticket. No try/catch in the controller.

## Task 5 [bonus, like the mock]: invalid data -> 400
Create InvalidTicketException. Before saving, reject a blank eventName or basePrice <= 0.
Add a second handler returning 400 with an ErrorResponse. Nothing invalid may be saved.

## Stretch
DELETE /tickets/{id}: 204 when it works, 404 through your handler when it does not.

## Section B checks (test these yourself before zipping)
1. GET /tickets -> 200, two seeded tickets, the two summaries read differently
2. GET /tickets/2 -> 200 with that one ticket
3. GET /tickets/999 -> 404 (not 500, not an empty 200)
4. The 404 body is JSON with a message naming 999
5. POST /tickets/vip {"eventName":"Opera Gala","basePrice":80,"backstagePass":false}
   -> 201 with id 3 and summary "VIP: Opera Gala | Backstage: no | £120.0"
6. POST /tickets/vip {"eventName":"Broken","basePrice":-10} -> 400 with a JSON message,
   and GET /tickets still shows only the earlier tickets
