package uk.ac.practice.tickets.service;

import org.springframework.stereotype.Service;
import uk.ac.practice.tickets.exception.InvalidTicketException;
import uk.ac.practice.tickets.exception.TicketNotFoundException;
import uk.ac.practice.tickets.model.Ticket;
import uk.ac.practice.tickets.model.VipTicket;
import uk.ac.practice.tickets.repository.TicketRepository;

import java.util.List;

@Service
public class TicketService {

    private final TicketRepository repository;

    // PROVIDED: constructor injection. Read it, do not change it.
    public TicketService(TicketRepository repository) {
        this.repository = repository;
    }

    // PROVIDED
    public List<Ticket> getAllTickets() {
        return repository.findAll();
    }

    // TASK 3 (solution)
    public Ticket getTicketById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new TicketNotFoundException(id));
    }

    // TASK 4 creates the endpoint; TASK 5 adds the validation (solution)
    public Ticket createVipTicket(VipTicket ticket) {
        if (ticket.getEventName() == null || ticket.getEventName().isBlank()) {
            throw new InvalidTicketException("Event name is required");
        }
        if (ticket.getBasePrice() <= 0) {
            throw new InvalidTicketException("Base price must be greater than zero");
        }
        ticket.setId(null);
        return repository.save(ticket);
    }

    // STRETCH (solution)
    public void deleteTicket(Long id) {
        getTicketById(id);
        repository.deleteById(id);
    }
}
