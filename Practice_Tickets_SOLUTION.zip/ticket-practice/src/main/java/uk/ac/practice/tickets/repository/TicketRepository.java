package uk.ac.practice.tickets.repository;

import uk.ac.practice.tickets.model.Ticket;

import java.util.List;
import java.util.Optional;

// PROVIDED: read it, do not edit it.
public interface TicketRepository {

    List<Ticket> findAll();

    Optional<Ticket> findById(Long id);

    Ticket save(Ticket ticket);

    void deleteById(Long id);
}
