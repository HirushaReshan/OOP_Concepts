package edu.practice.dispatch.controller;

import edu.practice.dispatch.dto.DispatchPlan;
import edu.practice.dispatch.dto.NewAirMission;
import edu.practice.dispatch.model.DispatchMission;
import edu.practice.dispatch.service.DispatchService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.Map;

@RestController
@RequestMapping("/api/missions")
public class DispatchController {

    private final DispatchService service;

    public DispatchController(DispatchService service) {
        this.service = service;
    }

    @GetMapping
    public Collection<DispatchMission> all() {
        return service.all();
    }

    // TASK 4: GET /api/missions/{id}/energy -> {"id":101,"energyUnits":39}
    @GetMapping("/{id}/energy")
    public Map<String, Object> energy(@PathVariable long id) {
        return Map.of("id", id, "energyUnits", service.energy(id));
    }

    // TASK 4: POST /api/missions/air -> 201 Created
    @PostMapping("/air")
    @ResponseStatus(HttpStatus.CREATED)
    public DispatchMission addAir(@RequestBody NewAirMission request) {
        return service.addAir(request);
    }

    // TASK 4: GET /api/missions/plan?capacity=60&urgentOnly=false
    @GetMapping("/plan")
    public DispatchPlan plan(@RequestParam int capacity,
                             @RequestParam(defaultValue = "false") boolean urgentOnly) {
        return service.plan(capacity, urgentOnly);
    }
}
