package edu.practice.dispatch.model;

// TASK 1 (model answer)
public class GroundMission extends DispatchMission {

    private final boolean medical;

    public GroundMission(long id, int distanceKm, int loadKg, boolean medical) {
        super(id, distanceKm, loadKg);
        this.medical = medical;
    }

    public boolean isMedical() {
        return medical;
    }

    @Override
    public int energyUnits() {
        long energy = 2L * getDistanceKm() + 5L * getLoadKg();   // long: cannot overflow here
        return Math.toIntExact(energy);                          // throws if it does not fit in int
    }

    @Override
    public int priority() {
        if (medical) {
            return 3;
        }
        return 1;
    }
}
