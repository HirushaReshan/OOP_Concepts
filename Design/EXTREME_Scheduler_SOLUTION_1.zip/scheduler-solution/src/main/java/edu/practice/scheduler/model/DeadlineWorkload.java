package edu.practice.scheduler.model;

// TASK 2 (model answer): a new file.
public class DeadlineWorkload extends Workload {

    private final int deadlineTick;

    public DeadlineWorkload(long id, int cpuCores, int memoryMb, int durationTicks,
                            int releaseTick, int deadlineTick) {
        super(id, cpuCores, memoryMb, durationTicks, releaseTick);
        this.deadlineTick = deadlineTick;
    }

    public int getDeadlineTick() {
        return deadlineTick;
    }

    @Override
    public int urgencyAt(int nowTick) {
        if (nowTick < 0) {
            throw new IllegalArgumentException("nowTick cannot be negative");
        }
        long slack = Math.max(0L, (long) deadlineTick - nowTick - getDurationTicks());
        long urgency = 1000L - 5L * slack;
        try {
            return Math.toIntExact(urgency);
        } catch (ArithmeticException e) {
            throw new IllegalArgumentException("Urgency is out of range");
        }
    }

    @Override
    public int latestStartTick() {
        return Math.subtractExact(deadlineTick, getDurationTicks());
    }
}
