package edu.practice.scheduler.model;

// TASK 1 (model answer)
public class BatchWorkload extends Workload {

    public BatchWorkload(long id, int cpuCores, int memoryMb, int durationTicks, int releaseTick) {
        super(id, cpuCores, memoryMb, durationTicks, releaseTick);
    }

    @Override
    public int urgencyAt(int nowTick) {
        if (nowTick < 0) {
            throw new IllegalArgumentException("nowTick cannot be negative");
        }
        long waited = Math.max(0L, (long) nowTick - getReleaseTick());
        long urgency = 100L + 2L * waited;
        try {
            return Math.toIntExact(urgency);
        } catch (ArithmeticException e) {
            throw new IllegalArgumentException("Urgency is too large");
        }
    }

    @Override
    public int latestStartTick() {
        return Integer.MAX_VALUE;          // no deadline: can start any time
    }
}
