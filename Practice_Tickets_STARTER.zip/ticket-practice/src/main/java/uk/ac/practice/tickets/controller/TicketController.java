package uk.ac.practice.tickets.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uk.ac.practice.tickets.model.Ticket;
import uk.ac.practice.tickets.service.TicketService;

import java.util.List;

@RestController
@RequestMapping("/tickets")
public class TicketController {

    private final TicketService service;

    // PROVIDED: constructor injection. Read it, do not change it.
    public TicketController(TicketService service) {
        this.service = service;
    }

    // PROVIDED
    @GetMapping
    public List<Ticket> getAll() {
        return service.getAllTickets();
    }

    // TASK 4 [20 marks]:
    //   GET  /tickets/{id}  -> 200 with that ticket (unknown id must become 404 via your handler)
    //   POST /tickets/vip   -> 201 Created with the saved VipTicket and its new id
    //   No try/catch in this class.
}
