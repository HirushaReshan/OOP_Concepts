package edu.practice.dispatch.service;

import edu.practice.dispatch.dto.DispatchPlan;
import edu.practice.dispatch.dto.NewAirMission;
import edu.practice.dispatch.dto.PlanLine;
import edu.practice.dispatch.error.MissionNotFoundException;
import edu.practice.dispatch.model.AirMission;
import edu.practice.dispatch.model.DispatchMission;
import edu.practice.dispatch.repo.MissionRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

@Service
public class DispatchService {

    private static final int MAX_VALUE = 10_000;

    private final MissionRepository repo;

    public DispatchService(MissionRepository repo) {
        this.repo = repo;
    }

    public Collection<DispatchMission> all() {
        return repo.all();
    }

    // TASK 3
    public int energy(long id) {
        DispatchMission mission = repo.find(id);
        if (mission == null) {
            throw new MissionNotFoundException(id);
        }
        return mission.energyUnits();
    }

    // TASK 3
    public DispatchMission addAir(NewAirMission request) {
        if (request == null) {
            throw new IllegalArgumentException("Request body is required");
        }
        if (request.id() <= 0) {
            throw new IllegalArgumentException("id must be a positive number");
        }
        if (request.distanceKm() <= 0) {
            throw new IllegalArgumentException("distanceKm must be greater than zero");
        }
        if (request.loadKg() < 0) {
            throw new IllegalArgumentException("loadKg cannot be negative");
        }
        if (request.windPenalty() < 0) {
            throw new IllegalArgumentException("windPenalty cannot be negative");
        }
        if (request.distanceKm() > MAX_VALUE || request.loadKg() > MAX_VALUE
                || request.windPenalty() > MAX_VALUE) {
            throw new IllegalArgumentException("Values must be between 0 and 10,000");
        }
        if (repo.exists(request.id())) {
            throw new IllegalArgumentException("A mission with id " + request.id() + " already exists");
        }
        AirMission mission = new AirMission(request.id(), request.distanceKm(),
                request.loadKg(), request.windPenalty(), request.critical());
        try {
            mission.energyUnits();                 // calculate once BEFORE saving
        } catch (ArithmeticException e) {
            throw new IllegalArgumentException("Energy value is too large");
        }
        repo.save(mission);
        return mission;
    }

    // TASK 2: deterministic greedy plan, no instanceof
    public DispatchPlan plan(int capacity, boolean urgentOnly) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("capacity must be greater than zero");
        }

        List<DispatchMission> ordered = repo.all().stream()
                .filter(m -> !urgentOnly || m.priority() >= 3)
                .sorted(Comparator.comparingInt(DispatchMission::priority).reversed()
                        .thenComparingInt(DispatchMission::energyUnits)
                        .thenComparingLong(DispatchMission::getId))
                .toList();

        int remaining = capacity;
        List<PlanLine> selected = new ArrayList<>();
        List<Long> skipped = new ArrayList<>();

        for (DispatchMission mission : ordered) {
            int energy = mission.energyUnits();
            if (energy <= remaining) {
                selected.add(new PlanLine(mission.getId(),
                        mission.getClass().getSimpleName(),
                        mission.priority(),
                        energy));
                remaining = remaining - energy;
            } else {
                skipped.add(mission.getId());
            }
        }
        return new DispatchPlan(capacity, capacity - remaining, remaining, selected, skipped);
    }
}
