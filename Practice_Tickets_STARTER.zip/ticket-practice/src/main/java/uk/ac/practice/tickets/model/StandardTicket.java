package uk.ac.practice.tickets.model;

// TASK 1 [18 marks]: complete this class.
//   (a) add a private String field called seatRow, with a getter and a setter
//   (b) add a full constructor (id, eventName, basePrice, seatRow) that calls super(...)
//   (c) calculatePrice(): a standard ticket costs exactly its base price
//   (d) getSummary(): return  "Standard: <eventName> | Row <seatRow> | £<price>"
public class StandardTicket extends Ticket {

    // TODO (a)

    public StandardTicket() {}

    // TODO (b)

    @Override
    public double calculatePrice() {
        return 0; // TODO (c)
    }

    @Override
    public String getSummary() {
        return "TODO"; // TODO (d)
    }
}
